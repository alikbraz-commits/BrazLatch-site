# 🧠 CLAUDE.md — BrazLatch Project Memory System

> **הוראות למודל:** קרא קובץ זה לפני כל פעולה בפרויקט.

---

## 📍 CONTEXT SNAPSHOT

```yaml
project: BrazLatch (a Braz Innovation product)
domain: brazlatch.com
owner: Alik Alexander Braz (inventor)
patent: US10934749B2 — "Sliding Bolt Latch and Use Thereof"
mission: Find licensees and distributors in 6 open markets
language_default: עברית for chat / English for product
session_goal: [תעדכן ידנית לפני כל סשן]
```

---

## 🏷️ PRODUCT ESSENTIALS

**BrazLatch** is a self-resetting spring bolt latch. Trapped-pin sequential release system. Animal-proof, vibration-proof, one-handed human operation. Auto-resets to locked when partial attempts are made.

**Origin story:** Invented by a stable owner after horses kept opening conventional latches.

**Applications:** Equestrian, livestock, trailers, backyards, logistic/warehouse, farms.

---

## 🌍 MARKET STATUS

| Market | Status |
|---|---|
| 🇺🇸 USA | ✅ Licensed to **National Hardware** (exclusive) — manufactures in China; sells through National Hardware, Amazon, Lowe's. All US packaging carries Alik's logo. |
| 🇨🇦 Canada | 🟢 OPEN — Priority 1 |
| 🇦🇺 Australia | 🟢 OPEN — Priority 1 |
| 🇬🇧 UK | 🟢 OPEN — Priority 2 |
| 🇪🇺 Europe | 🟢 OPEN — Priority 2 |
| 🇮🇳 India | 🟢 OPEN — Long-term |
| 🇨🇳 China | 🟢 OPEN — ⚠️ IP-cautious |

**Ajustco:** past partner (tried European distribution, ended), still useful for industry connections only.

### 🔑 The Manufacturing Advantage
National Hardware manufactures in China. Alik can purchase finished product from their production line. **This means new licensees don't need to build manufacturing from day one** — they can buy ready inventory, build distribution, scale, then transition to local manufacturing later. **This is the killer sales angle.**

---

## 🎨 BRAND IDENTITY

```yaml
parent_brand: Braz Innovation
product: BrazLatch (first product — more inventions planned)
logo: "brAz" wordmark with green 'A' + "INNOVATION" subtitle
colors:
  black: "#0a0a0a"      # primary background
  white: "#ffffff"       # primary text on dark
  green: "#6cb04a"       # accent (from logo — refine from actual SVG)
  cream: "#f5f1ea"       # alternative section bg
mood: industrial confidence + warm authenticity (horses + engineering)
```

---

## 🔌 INSTALLED PLUGINS

```
superpowers@claude-plugins-official    → enhanced capabilities
get-shit-done-cc (npx)                 → action-first mode
context-mode@context-mode              → smart context switching
claude-mem@thedotmack                  → persistent memory
skill-creator@claude-plugins-official  → skill authoring
frontend-design@claude-plugins-official → UI design
```

**Recommended marketing skills (install in Claude Code):**
```bash
/plugin marketplace add thatrebeccarae/claude-marketing
/plugin install seo-content-writer@claude-marketing
/plugin install content-workflow@claude-marketing
/plugin install email-composer@claude-marketing
```

---

## 🧠 MEMORY ARCHITECTURE

### Layer 1 — this file (always loaded)
### Layer 2 — claude-mem (persistent across sessions)
```
"זכור: [fact]"             → save
"recall [topic]"            → retrieve
"mem: save session"         → close session
```

**Categories:**
- `mem:markets`  — market research per country
- `mem:contacts` — companies / leads
- `mem:content`  — approved marketing copy
- `mem:deals`    — active negotiations
- `mem:website`  — site-related decisions

### Layer 3 — context-mode
```
"context: website"     → website project
"context: canada"      → Canada market work
"context: australia"   → Australia market work
"context: outreach"    → B2B outreach
"context: deck"        → license pitch deck
```

---

## ⚡ WORKING RULES

1. **Action first** (GSD mode) — execute, don't over-ask
2. **Save everything to mem** — research, decisions, contacts
3. **Target-market language** — content for Canada/AU/UK in English; Europe per country
4. **B2B focused** — the customer is a company, not a consumer (except US end-buyers → existing retailers)
5. **Patent + proof always present** — every outreach mentions US10934749B2 + National Hardware success

---

## 📁 PROJECT STRUCTURE

```
brazlatch/
├── CLAUDE.md                  ← this file
├── .claude/
│   ├── memory/                ← claude-mem
│   └── contexts/              ← context-mode
├── product/
│   └── patent-summary.md
├── website/                   ← the website project
│   ├── website-brief-v2.md
│   └── (Astro project once built)
├── marketing/
│   ├── pitch-deck/
│   ├── outreach-emails/
│   └── brand-voice.md
├── market-research/
│   ├── canada/
│   ├── australia/
│   ├── uk/
│   ├── europe/
│   ├── india/
│   └── china/
└── assets/
    ├── 3d-renders/
    ├── icons/
    ├── photos/
    └── videos/
```

---

## 💬 QUICK COMMANDS

```
"build the website from website-brief-v2.md"  → Claude Code starts building
"market research [country]"                    → deep market analysis
"draft cold email for [industry] in [country]" → B2B outreach
"license pitch deck for [market]"              → presentation
"summary of what you know about BrazLatch"     → context dump
```

---

## 🚀 SESSION CHECKLIST

**Opening:**
- [ ] Read CLAUDE.md
- [ ] `recall last-session`
- [ ] Set `context: [topic]`

**Closing:**
- [ ] `mem: save [summary]`
- [ ] Update Market Status if changed

---

*Updated: May 2025 | Version 3.0 | brazlatch.com | Patent US10934749B2*
